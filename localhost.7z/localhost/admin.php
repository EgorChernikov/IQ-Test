<?ob_start();?> 
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.0.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="style.css">
</head>

<body>


<br/>

<div class="container">
<ul class="nav nav-tabs" id="MyTabs">
  <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#Students">Студенты</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#Question">Задания</a>
  </li>
  
</ul>
<br/>
</div>

 <?php
include('ConnectDB.php');
function redirect_to($new_location) {//функция для отмены повторной отправки формы
header("Location: " . $new_location);//(редирект)
exit();
}

?>  

<div class="tab-content" id="Tabs">
  <div class="tab-pane active container" id="Students"><?php include('Students.php'); ?></div>
  <div class="tab-pane container" id="Question"><?php include('Question.php');  ?></div>
  


</body>
</html>