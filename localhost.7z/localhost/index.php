<?php
session_start();

if ($_SESSION['user']) {
    header('Location: profile.php');
}

?>
<!DOCTYPE html>
<html lang="ru-RU">
<head>
<?php
	
	
	require_once "Functions/Functions.php";
	 $Question = getQuestion(1);


?>
<link rel="stylesheet" href="/css/style.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IQ тест</title>


</head>
<body>
<div class="authorise" >

<div class="col-2-3" >
		<h1> IQ тестирование студентов      </h1>
		<h2> данное тестирование рзработанно специально для студентов бакалавров 1-4 курса.
		<p>	Тест выполняется в течении 30 минут   </p>   </h2> 
</div>
<center>
<div class="col-1-3" >
 <form>
        <label>Логин</label>
        <input type="text" name="login"   placeholder="Введите свой логин" >
        <label>Пароль</label>
        <input type="password" name="password"  placeholder="Введите пароль">
        <button type="submit" class="login-btn">Войти</button>
        <p>
            У вас нет аккаунта?  <a href="/register.php">зарегистрируйтесь</a>!
        </p>
        <p>
            админ панель  <a href="/admin.php">войти</a>!
        </p>
        <p class="msg none"></p>
	</form>
	
          </center>

</div>
<script src="Functions/js/jquery-3.4.1.min.js"></script>
<script src="Functions/js/valid.js"></script>

	
		
	

	
</body>
</html>