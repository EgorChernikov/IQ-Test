<?php
    //Валидация переменных
    if($_POST["full_name"] || $_POST["login"] || $_POST["possword"] || $_POST["avatar"]){

        $full_name = ($_POST["full_name"]);
        $login = ($_POST["login"]);
        $password = ($_POST["possword"]);
        $avatar = ($_POST["avatar"]);

        
            //Если это запрос на обновление, то обновляем
            if (isset($_GET['red_id'])) {//ОСТАВИТЬ ИЛИ ПОМЕНЯТЬ НА !empty
                $id = trim($_GET['red_id']);
                $sql = "UPDATE `student` SET full_name=?, login=?, password=?, avatar=?  WHERE Id=?";
                $query = $pdo->prepare($sql);
                $query->execute(array($full_name, $login, $password,$avatar,$Id));
                redirect_to('admin.php');
            } else {//Если НЕ запрос на обновление, то добавляем новую запись
                $sql = ("INSERT INTO student (full_name, login, password, avatar) VALUES (:full_name,:login,:password, :avatar)");
                $params = [':full_name' => $full_name, ':login' => $login, ':password' => $password, ':avatar' => $avatar];
                $query = $pdo->prepare($sql);
                $result = $query->execute($params);
                redirect_to('admin.php');
            }
        
    }

    if (isset($_GET['del_id'])) {//Удалем уже существующую запись
        $id = trim($_GET['del_id']);
        $sql = "DELETE FROM student WHERE Id=?";
        $query = $pdo->prepare($sql);
        $query->execute(array($id));
        redirect_to('admin.php');
    }

    if (isset($_GET['red_id'])) {
        $id = trim($_GET['red_id']);
        $sql =  ("SELECT Id, full_name, login, password, avatar FROM student WHERE Id=?");
        $query = $pdo->prepare($sql);
        $query->execute(array($id));
        $student = $query->fetch(PDO::FETCH_LAZY);
    }

    ?>
  <div>
    <p><b>Готовые изделия ЦМИТ</b></p>  
        <form action="" method="post">
            <table>
                <tr>

                    <td><input type="text" name="full_name" placeholder="Наименование изделия" class="form-control" value="<?= isset($_GET['red_id']) ? $student['full_name'] : $name; ?>"></td>
                </tr>
                <tr>
                    <td><input type="text" name="login"  placeholder="жопа" class="form-control" value="<?= isset($_GET['red_id']) ? $student['login'] : $price; ?>">
                    </td>
                    <tr>
                    <td><input type="text" name="password"  placeholder="Член" class="form-control" value="<?= isset($_GET['red_id']) ? $student['password'] : $price; ?>">
                    </td>
                    <td><input type="text" name="avatar"  placeholder="пися" class="form-control" value="<?= isset($_GET['red_id']) ? $student['avatar'] : $price; ?>">
                    </td>
                    <td colspan="2"><input type="submit" class="btn btn-success" value="OK"></td>
                </tr>
            </table>
        </form>

  <table class="table table-bordered" border='1'>
    <thead>
    <tr>
      <th>ФИО</th>
      <th>Логин</th>
      <th>Пароль </th>
      <th>URL аватара</th>
      <th width="10%">Удаление</th>
      <th width="10%">Редактирование</th>
    </tr>
  </thead>
    <br/>


<?php
    echo $msg;
    $sql = $pdo->query('SELECT `Id`, `full_name`, `login`,`password`,`avatar` FROM student');
    while ($result = $sql->fetch()) {//Заполнение полей таблицы данными из БД
        echo '<tr>' .
        "<td>{$result['full_name']}</td>" .
        "<td>{$result['login']} ₽</td>" .
        "<td>{$result['password']}</td>" .
        "<td>{$result['avatar']}</td>" .
        "<td><a style=\"text-decoration: none;\" href='?del_id={$result['Id']}'><button class=\"btn btn-outline-danger\" style=\"display: flex; margin: auto;\">Удалить</button></a></td>" .
        "<td><a  style=\"text-decoration: none;\" href='?red_id={$result['Id']}'><button class=\"btn btn-outline-info\" style=\"display: flex; margin: auto;\">Изменить</button></a></td>" .
        '</tr>';
      }
?>
  </table>
<br/>
</div>
