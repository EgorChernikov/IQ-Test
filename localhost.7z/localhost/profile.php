<?php
session_start();
if (!$_SESSION['user']) {
    header('Location: /');
}
?>

<!doctype html>
<html lang="en">
<head>
<?php
	
	
	require_once "Functions/Functions.php";
	 $Question = getQuestion(11);


?>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="css/style.css">

<script>
 
 var Student_answer = 0;

 let data_array = [];
  var number_of_qestion = 1;
  var yes = 0;

 

function user_answer(num, correct_answer,i){
  
  

  
    if(num == 0){
     
      
      startTimer()
      <?php 
      echo $i;    
        ?>
      
      document.getElementById('question1').style.display='block';

    document.getElementById('start').style.display='none';
		// document.getElementById('end').style.display='inline';

  } 
  if(i == 1){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }
    

    document.getElementById('question2').style.display='block';
    document.getElementById('question1').style.display='none';

  }
  if(i == 2){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }
    document.getElementById('question3').style.display='block';
    document.getElementById('question2').style.display='none';

  }
  if(i == 3){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }

    document.getElementById('question4').style.display='block';
    document.getElementById('question3').style.display='none';

  }
  if(i == 4){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }

    document.getElementById('question5').style.display='block';
    document.getElementById('question4').style.display='none';

  }
  if(i == 5){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }

    document.getElementById('question6').style.display='block';
    document.getElementById('question5').style.display='none';

  }
  if(i == 6){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }

    document.getElementById('question7').style.display='block';
    document.getElementById('question6').style.display='none';

  }
  if(i == 7){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }

    document.getElementById('question8').style.display='block';
    document.getElementById('question7').style.display='none';

  }
  if(i == 8){
    Student_answer = num;
    data_array[number_of_qestion] = Student_answer;
    if(num == correct_answer){
      yes++;
    }
    if(yes<3 && yes>=0 ){
      document.getElementById('rezult1').style.display='block';
    }
    if(yes<5 && yes>2 ){
      document.getElementById('rezult2').style.display='block';
    }
    if(yes>4){
      document.getElementById('rezult3').style.display='block';
    }

    
    

   // document.getElementById('question9').style.display='block';
    document.getElementById('question8').style.display='none';

  }
  // if(i == 9){
  //   Student_answer = num;
  //   data_array[number_of_qestion] = Student_answer;
  //   if(num == correct_answer)
  //   alert("Ты смог!");

  //   document.getElementById('question10').style.display='block';
  //   document.getElementById('question9').style.display='none';

  // }
  // if(i == 10){
  //   Student_answer = num;
  //   data_array[number_of_qestion] = Student_answer;
  //   if(num == correct_answer)
  //   alert("Ты смог!");

 
  //   document.getElementById('question10').style.display='none';

  // }
  // else { Student_answer = num;
  //   data_array[number_of_qestion] = Student_answer;
  //   if(num == correct_answer)
  //   alert("Ты смог!");
    
    
    
  // }
  

}

// _______________________________________________________________________Timer_____________________________________________________

  function startTimer() {
    var my_timer = document.getElementById("my_timer");
    var time = my_timer.innerHTML;
    var arr = time.split(":");
    var m = arr[0];
    var s = arr[1];
    if (s == 0) {
      if (m == 0) {
       
        document.getElementById('question1').style.display='none';
        document.getElementById('question2').style.display='none';
        document.getElementById('question3').style.display='none';
        document.getElementById('question4').style.display='none';
        document.getElementById('question5').style.display='none';
        document.getElementById('question6').style.display='none';
        document.getElementById('question7').style.display='none';
        document.getElementById('question8').style.display='none';
        if(yes<3 && yes>=0 ){
      document.getElementById('rezult1').style.display='block';
    }
    if(yes<5 && yes>2 ){
      document.getElementById('rezult2').style.display='block';
    }
    if(yes>4){
      document.getElementById('rezult3').style.display='block';
    }
       
          return;
      }
      m--;
      if (m < 10) m = "0" + m;
      s = 59;
    }
    else s--;
    if (s < 10) s = "0" + s;
    document.getElementById("my_timer").innerHTML = m+":"+s;
    setTimeout(startTimer, 1000);
  }

</script>
</head>
<body>

          <!-- Профиль -->
<div class="pirfile">
    <form>
        <img src="<?= $_SESSION['user']['avatar'] ?>" width="200" alt="">
        <h2 style="margin: 10px 0;"><?= $_SESSION['user']['full_name'] ?></h2>
        <a href="Functions/logout.php" class="logout">Выход</a>
    </form>

    <div>
    <button id="start" class="start" onclick="user_answer(0)" >начать тест</button>

  </div>
</div>
  
  <p><span id="my_timer" style="color: #f00; font-size: 150%; font-weight: bold;">30:00</span></p>
    
  <?php
//рандомизация
function unic_rnd($start, $end, $count){
  $array_r =array();
  $i=-1;
  while($i++ < $count){
  $rnd = rand($start, $end);
  if(!in_array($rnd, $array_r)){
  $array_r[] = $rnd;
  }
  else{
  $count=$count+1;
  }
  }
  return $array_r;
  
  }
  $rnd =unic_rnd(1,9, 8);

//------------------------тестирование----------------------------------
   $i= 1;
    $number_of_question = $rnd[$i];  
   
      echo '<div class="question" id="question1">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',1)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',1)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];
     
      echo '<div class="question" id="question2">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',2)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',2)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      echo '<div class="question" id="question3">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',3)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',3)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];



      echo '<div class="question" id="question4">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',4)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',4)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      echo '<div class="question" id="question5">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',5)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',5)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      echo '<div class="question" id="question6">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',6)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',6)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      echo '<div class="question" id="question7">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',7)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',7)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      echo '<div class="question" id="question8">';
      echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      $correct_answer = $Question[$number_of_question]["answer"];
      echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',8)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',8)" class="button"> следующий </button>';
      echo '</div>';
      $i++;
      $number_of_question = $rnd[$i];

      // $i++;
      // $number_of_question = $rnd[$i];
      // echo '<div class="question" id="question9">';
      // echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      // $correct_answer = $Question[$number_of_question]["answer"];
      // echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',9" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      // echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',9)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      // echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',9)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      // echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',9)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      // echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',9)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      // echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',9)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      // echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',9)" class="button"> следующий </button>';
      // echo '</div>';

      // $i++;
      // $number_of_question = $rnd[$i];
      // echo '<div class="question" id="question10">';
      // echo '<img src="/data/'.$Question[$number_of_question]["url_question"].'.PNG">';
      // $correct_answer = $Question[$number_of_question]["answer"];
      // echo '<button  onclick="user_answer(1,'. $Question[$number_of_question]["answer"].',10" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer1"].'.PNG" class="image"  id="answer1" </button>';
      // echo '<button  onclick="user_answer(2, '. $Question[$number_of_question]["answer"].',10)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer2"].'.PNG" class="image"  id="answer2"</button>';
      // echo '<button  onclick="user_answer(3,'. $Question[$number_of_question]["answer"].',10)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer3"].'.PNG" class="image"  id="answer3"</button>';
      // echo '<button  onclick="user_answer(4, '. $Question[$number_of_question]["answer"].',10)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer4"].'.PNG" class="image"  id="answer4"</button>';
      // echo '<button onclick="user_answer(5,'. $Question[$number_of_question]["answer"].',10)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer5"].'.PNG" class="image"  id="answer5"</button>';
      // echo '<button onclick="user_answer(6,'. $Question[$number_of_question]["answer"].',10)" class="button"> <img " src="/data/'.$Question[$number_of_question]["url_answer6"].'.PNG" class="image"  id="answer6"</button>';
      // echo '<button onclick="user_answer(7,'. $Question[$number_of_question]["answer"].',10)" class="button"> слудующий </button>';
      // echo '</div>';

//---------------------------------------------вывод результатов-------------------
?>

<div id="rezult1" class="rezult">
  Ваш IQ = 80
</div>
<div id="rezult2" class="rezult">
  Ваш IQ = 100
</div>
<div id="rezult3" class="rezult">
  Ваш IQ = 120
 
</div>
<table>
<caption>Предыдущие тестирования</caption>
  <tr>
    <th>№ п/п</th>
    <th>дата тестирования</th>
    <th>баллы за тест</th>
  </tr>
  <tr>
    <td>1.</td>
    <td>12.06.20</td><td>102</td>
  </tr>
  <tr>
    <td>2.</td>
    <td>13.06.20</td><td>95</td>
  </tr>
  <tr>
    <td colspan="2" style="text-align:right">СРЕДНИЙ БАЛЛ:</td><td>98,5</td>
  </tr>
  </table>

</body>
</html>



