<?php
    session_start();
    if ($_SESSION['user']) {
        header('Location: profile.php');
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Регистрация</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

    <!-- Форма регистрации -->
    <div class="register">
    <form>
        <label>ФИО</label>
        <input type="text" name="full_name" placeholder="Введите свое полное имя">
        <label>Логин</label>
        <input type="text" name="login" placeholder="Введите свой логин">
        <label>Изображение профиля</label>
        <input type="file" name="avatar">
        <label>Пароль</label>
        <input type="password" name="password" placeholder="Введите пароль">
        <button type="submit" class="register-btn">Зарегистрироваться</button>
        <p>
            У вас уже есть аккаунт? - <a href="/">авторизируйтесь</a>!
        </p>
        <p class="msg none"></p>
    </form>
    </div>
    <script src="Functions/js/jquery-3.4.1.min.js"></script>
    <script src="Functions/js/valid.js"></script>

</body>
</html>