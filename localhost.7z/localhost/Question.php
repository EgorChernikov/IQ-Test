<?php
    //Валидация переменных
    if($_POST["answer"] || $_POST["url_question"] || $_POST["url_answer1"] || $_POST["url_answer2"] || $_POST["url_answer3"] || $_POST["url_answer4"] || $_POST["url_answer5"] || $_POST["url_answer6"]){

        $answer = ($_POST["answer"]);
        $url_question = ($_POST["url_question"]);
        $url_answer1 = ($_POST['url_answer1']);
        $url_answer2 = ($_POST['url_answer2']);
        $url_answer3 = ($_POST['url_answer3']);
        $url_answer4 = ($_POST['url_answer4']);
        $url_answer5 = ($_POST['url_answer5']);
        $url_answer6 = ($_POST['url_answer6']);

        
            //Если это запрос на обновление, то обновляем
            if (isset($_GET['quest_id'])) {//ОСТАВИТЬ ИЛИ ПОМЕНЯТЬ НА !empty
                $id = trim($_GET['quest_id']);
                $sql = "UPDATE `questions_with_image` SET answer=?, url_question=?, url_answer1=?, url_answer2=?, url_answer3=?, url_answer4=?, url_answer5=?, url_answer6=?  WHERE id=?";
                $query = $pdo->prepare($sql);
                $query->execute(array($answer , $url_question, $url_answer1,$url_answer2,$url_answer3,$url_answer4,$url_answer5,$url_answer6,$id));
                redirect_to('admin.php');
            } else {//Если НЕ запрос на обновление, то добавляем новую запись
                $sql = ("INSERT INTO questions_with_image (answer, url_question,url_answer1, url_answer2,url_answer3,url_answer4,url_answer5,url_answer6) VALUES (:answer,:url_question,:url_answer1, :url_answer2, :url_answer3, :url_answer4, :url_answer5, :url_answer6)");
                $params = [':answer' => $answer, ':url_question' => $url_question, ':url_answer1' => $url_answer1, ':url_answer2' => $url_answer2, ':url_answer3' => $url_answer3, ':url_answer4' => $url_answer4, ':url_answer5' => $url_answer5, ':url_answer6' => $url_answer6];
                $query = $pdo->prepare($sql);
                $result = $query->execute($params);
                redirect_to('admin.php');
            }
        
    }

    if (isset($_GET['dell_id'])) {//Удалем уже существующую запись
        $id = trim($_GET['dell_id']);
        $sql = "DELETE FROM questions_with_image WHERE id=?";
        $query = $pdo->prepare($sql);
        $query->execute(array($id));
        redirect_to('admin.php');
    }

    if (isset($_GET['quest_id'])) {// Передаем данные редактируемого товара в поля
        $id = trim($_GET['quest_id']);
        $sql =  ("SELECT id, answer, url_question, url_answer1, url_answer2,url_answer3,url_answer4,url_answer5,url_answer6 FROM questions_with_image WHERE d=?");
        $query = $pdo->prepare($sql);
        $query->execute(array($id));
        $student = $query->fetch(PDO::FETCH_LAZY);
    }

    ?>



<div>
  <p><b>Вопросы с картинками</b></p>
   <form action="" method="post">
    <table>
      <tr>

        <td><input type="text" name="answer" size="2" placeholder="Ответ" class="form-control" value="<?= isset($_GET['quest_id']) ? $service['answer'] : $answer; ?>"></td>
      </tr>
      <tr>
        <td><input type="text" name="url_question"  placeholder="Изображение вопрос" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_question'] : $url_question; ?>">
        </td>
        <td><input type="text" name="url_answer1" size="3" placeholder="Ответ 1" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer1'] : $url_answer1; ?>">
        </td>
        <td><input type="text" name="url_answer2" size="3" placeholder="Ответ 2" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer2'] : $url_answer2; ?>">
        </td>
        <td><input type="text" name="url_answer3" size="3" placeholder="Ответ 3" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer3'] : $url_answer3; ?>">
        </td>
        <td><input type="text" name="url_answer4" size="3" placeholder="Ответ 4" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer4'] : $url_answer4; ?>">
        </td>
        <td><input type="text" name="url_answer5" size="3" placeholder="Ответ 5" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer5'] : $url_answer5; ?>">
        </td>
        <td><input type="text" name="url_answer6" size="3" placeholder="Ответ 6" class="form-control" value="<?= isset($_GET['quest_id']) ? $questions_with_image['url_answer6'] : $url_answer6; ?>">
        </td>
        
         <td colspan="2"><input type="submit" class="btn btn-info" value="OK"></td>
      </tr>
    </table>
  </form>
 <table class="table table-bordered" border='1'>
    <thead>
    <tr>

      <th width="20%">Ответ</th>
      <th width="30%">Картинка ответа</th>
      <th width="30%">Картинка первого вопроса</th>
      <th width="30%">Картинка второго вопроса</th>
      <th width="30%">Картинка третьего вопроса</th>
      <th width="30%">Картинка четвёртого вопроса</th>
      <th width="30%">Картинка пятого вопроса</th>
      <th width="30%">Картинка шестого вопроса</th>
    </tr>
  </thead>
<br/>
<?php
    echo $msg1;
    $sql1 = $pdo->query("SELECT id, answer, url_question,url_answer1, url_answer2, url_answer3, url_answer4, url_answer5, url_answer6 FROM questions_with_image");
    while ($result = $sql1->fetch()) {//Заполнение полей таблицы данными из БД
      echo '<tr>' .
           "<td>{$result['answer']}</td>" .
           "<td>{$result['url_question']} ₽</td>" .
           "<td>{$result['url_answer1']}</td>" .
           "<td>{$result['url_answer2']}</td>" .
           "<td>{$result['url_answer3']}</td>" .
           "<td>{$result['url_answer4']}</td>" .
           "<td>{$result['url_answer5']}</td>" .
           "<td>{$result['url_answer6']}</td>" .
           "<td><a style=\"text-decoration: none;\" href='?dell_id={$result['id']}'><button class=\"btn btn-danger\" style=\"display: flex; margin: auto;\">Удалить</button></a></td>" .
           "<td><a style=\"text-decoration: none;\" href='?quest_id={$result['id']}'><button class=\"btn btn-primary\" style=\"display: flex; margin: auto;\">Изменить</button></a></td>" .
           '</tr>';
    }
?>
  </table>
  <br/>
</div>