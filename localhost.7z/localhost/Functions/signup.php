<?php

    session_start();
    require_once 'connect.php';

    $full_name = $_POST['full_name'];
    $login = $_POST['login'];
    $password = $_POST['password'];

    $check_login = mysqli_query($connect, "SELECT * FROM `student` WHERE `login` = '$login'");
if (mysqli_num_rows($check_login) > 0) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "Такой логин уже существует",
        "fields" => ['login']
    ];

    echo json_encode($response);
    die();
}

$error_fields = [];

if ($login === '') {
    $error_fields[] = 'login';
}

if ($password === '') {
    $error_fields[] = 'password';
}

if ($full_name === '') {
    $error_fields[] = 'full_name';
}


if (!$_FILES['avatar']) {
    $error_fields[] = 'avatar';
}

if (!empty($error_fields)) {
    $response = [
        "status" => false,
        "type" => 1,
        "message" => "Проверьте правильность полей",
        "fields" => $error_fields
    ];

    echo json_encode($response);

    die();
}

   

    

$path = 'uploads/' . time() . $_FILES['avatar']['name'];
if (!move_uploaded_file($_FILES['avatar']['tmp_name'], '../' . $path)) {
    $response = [
        "status" => false,
        "type" => 2,
        "message" => "Ошибка при загрузке аватарки",
    ];
    echo json_encode($response);
}

$password = md5($password);

      

        mysqli_query($connect, "INSERT INTO `student` (`Id`, `full_name`, `login`, `password`, `avatar`) VALUES (NULL, '$full_name', '$login', '$password', '$path')");

        $response = [
            "status" => true,
            "message" => "Успешная регистрация",
            
        ];
      


    

?>
